// ==UserScript==
// @name         Adblock4limbo
// @namespace    https://greasyfork.org/zh-CN/scripts/443290-adblock4limbo-adsremoveproject
// @version      0.2.2
// @license      CC BY-NC-SA 4.0
// @description  毒奶去广告计划油猴脚本版；通过 JavaScript 移除Pornhub/搜索引擎（Bing/Google）内容农场结果清除/低端影视（可避免PC端10秒广告倒计时）/独播库/ibvio/Jable（包含M3U8文件提取）/MissAv（禁止离开激活窗口视频自动暂停播放）/禁漫天堂/紳士漫畫/91porn/哔滴影视（加速跳过视频广告/避免反查）/555电影网（o8tv）等视频网站上的视频广告和图片广告，保持界面清爽干净无打扰！其他：优化PC端未登录状态访问知乎浏览体验（动态移除登录窗口/永远不会跳转至首页登录页面）；
// @author       limbopro
// @match        https://ddrk.me/*
// @match        https://ddys.tv/*
// @match        https://ddys.art/*
// @match        https://ddys2.me/*
// @match        https://jable.tv/*
// @match        https://www.btbdys.com/*
// @match        https://www.bdys01.com/*
// @match        https://cn.pornhub.com/*
// @match        https://www.pornhub.com/*
// @match        https://missav.com/*
// @match        https://91porn.com/*
// @match        https://avple.tv/*
// @match        https://18comic.org/*
// @match        https://18comic.vip/*
// @match        https://www.5dy5.cc/*
// @match        https://www.5dy6.cc/*
// @match        https://www.5dy7.cc/*
// @match        https://www.5dy8.cc/*
// @match        https://www.o8tv.com/*
// @match        https://www.555dd5.com/*
// @match        https://www.555dd6.com/*
// @match        https://www.555dd7.com/*
// @match        https://www.555dd8.com/*
// @match        https://o8tv.com/*
// @match        https://www.wnacg.com/*
// @match        https://www.wnacg.org/*
// @match        https://w.duboku.io/*
// @match        https://www.duboku.tv/*
// @match        https://www.libvio.com/*
// @match        https://www.tvn.cc/*
// @match        https://m.tvn.cc/*
// @match        https://www.google.com/search*
// @match        https://www.google.com.hk/search*
// @match        https://www.bing.com/*
// @match        https://zhuanlan.zhihu.com/*
// @match        https://www.zhihu.com/*
// @match        https://www.instagram.com/*
// @match        https://www.nbys.tv/*
// @match        https://www.ttsp.tv/*
// @match        http://www.tz659.com/*
// @match        https://anime1.me/*
// @match        https://m.yhdmp.cc/*
// @match        https://m.yhdmp.com/*
// @match        https://m.yhpdm.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=limbopro.com
// @run-at       document-end
// @require https://greasyfork.org/scripts/442253-%E5%B1%8F%E8%94%BD%E5%86%85%E5%AE%B9%E5%86%9C%E5%9C%BA-with-%E6%B2%B9%E7%8C%B4%E8%84%9A%E6%9C%AC/code/%E5%B1%8F%E8%94%BD%E5%86%85%E5%AE%B9%E5%86%9C%E5%9C%BA%EF%BC%88with%20%E6%B2%B9%E7%8C%B4%E8%84%9A%E6%9C%AC%EF%BC%89.user.js
// @grant        none
// ==/UserScript==

// 引用地址 https://github.com/limbopro/Adblock4limbo/blob/main/Adguard/Adblock4limbo.user.js

// 一些常量
const imax = {
  js: {
    //functionx: "https://limbopro.com/Adguard/Adblock4limbo.function.js", // 全局js
    duboku: "https://limbopro.com/Adguard/duboku.js", // 独播库
    avple: "https://limbopro.com/Adguard/avple.js", // avple
    contentFarm: "https://limbopro.com/Adguard/contentFarm.js" // 内容农场
  },
  css: {
    globalcss: "https://limbopro.com/CSS/Adblock4limbo.user.css", // 全局
    libvio:
      '.hidden-log ,a[target="_blank"] > .img-responsive ,.advertise ,#adsbox ,.t-img-box ,.inner-advertise ,.advertise  {display: none! important;}', // libvio
    goole: "#tvcap,[data-text-ad] {display:none !important}", // 谷歌搜索广告
    avple:
      '#adsbox,.asg-overlay,.jss20,.jss13,iframe,span[class*=MuiSkeleton-root],.jss16 ,.MuiSkeleton-pulse.jss12.MuiSkeleton-rect.MuiSkeleton-root,[id*=KnvW],img[src*=".gif"],iframe[data-width] {display: none! important;}', // avple
    btbdys:
      'a[href*=\'z2py\'], a[href*=\'dodder\'], .ayx[style^="position: fixed;bottom"],#ad-index,#adsbox,.ayx[style="display:block;"],.ayx[style^="position: fixed;bottom"],a[target*=_new] {display:none !important;}', // 哔滴影视
    switch: ".switch {display:none !important}",
    ddrk: "#fkasjgf {display: none !important}",
    //ddrk: "a[href*=\"/kst6632.com/\"] { pointer-events: none !important; } a[href*=\"/kst6632.com/\"] > img { width: 1px !important; } a[onclick^=\"ClickobayST();\"]  #fkasjgf {display: none !important} a[href=\"###\"] img:not(#trk_hcaptcha):not([src^=\"https://captcha.su.baidu.com\"]) {display: none !important} a[href^=\"javascript\"] img:not(#trk_hcaptcha):not([src^=\"https://captcha.su.baidu.com\"]) {display: none !important}",
    jable:
      'div.asg-interstitial,div.asg-interstitial__mask,iframe,div[class*="exo"], .exo-native-widget-outer-container,a[target*="_blank"],a[href*="trwl1"],div[data-width="300"],div.text-center.mb-e-30,div[data-width*="300"],div[style*="300px"],section[class*="justify"],iframe[width="728"][height="90"],#site-content > div.container > section.pb-3.pb-e-lg-40.text-center,.text-center > a[target="_blank"] > img,a[href*="?banner="],[class*="root--"],.badge,a[href="http://uus52.com/"] {display :none !important; pointer-events: none !important;}', // Jable.tv
    test: "*, div,img {display: none !important}",
    comic_18:
      "[target='_blank'],.modal-backdrop,[data-height*='90'],div[data-height='250'][data-width='300'],a[href^='http']:not([href*='18comic.']) > img ,#adsbox ,a[target='_blank'][rel*='nofollow'] > img[src*='.gif'] ,#guide-modal ,iframe[width='300'][height='250'] ,.modal-body > ul.pop-list,.adsbyexoclick,div[data-group^='skyscraper_'],.bot-per,.top-a2db,a[href*='.taobao.com'],div[data-height='264'][data-width='956'],div[style^='position: fixed; top:'],.bot-per.visible-xs.visible-sm  {display: none !important; pointer-events: none !important;}", // 555电影网
    dy555:
      'a[target="_blank"] img,.playtop.col-pd,a[href*="?channelCode="] > img[src*=".com:"],#adsbox,div.myui-panel.myui-panel-bg.clearfix.wapad {display:none !important}', // 555影院
    wnacg:
      "div > img[src*='gif'],div.sh,div > a[target='_blank'] > img {display:none !important}", // 绅士漫画
    missav:
      "img[src*='.gif'], iframe,#a[href*='//bit.ly/'],div[style*='z-index: 1001'],ul.space-y-2.mb-4.ml-4.list-disc.text-nord14,div.space-y-5.mb-5,div.under_player,div[style=\"width: 300px; height: 250px;\"] {display:none !important; pointer-events:none important;}", //  MissAV
    porn91:
      'img[class*="ad_img"], iframe[src*="ads"], img[href*=\'.gif\'] {display:none ! important; pointer-events: none !important;}', // 91porn
    zhihuAds:
      "div.css-1izy64v,[class='Card AppBanner'],.Footer,.Banner-link,div.Pc-word {display:none ! important; pointer-events: none !important;}",
    pornhubx:
      "#header.hasAdAlert {grid-template-rows:60px 40px 0px !important} div.hd.clear, div > img[data-title][srcset], #js-networkBar,div#abAlert, .adsbytrafficjunky, #pb_template, .sponsor-text, #adsbox, .abAlertShown, .abAlertInner, #main-container > .abovePlayer, [rel*='noopener nofollow'],a[href^=\"http://ads.trafficjunky.net/\"], .topAdContainter,.adsbytrafficjunky,.ad-link,a[target='_blank'] {height:0px !important; display:none !important; pointer-events:none;}", // pornhub
    instagram: "div._aagw {display:none !important}", // 网页版Instagram不能复制图片的问题
    ttsp: 'div#playad1,a[href*="8616.tech"],.play_list_adbox,#adsbox,.ads_all > .ads_w,.ads_box,.right_ads {display:none !important}',
    tz659:
      "figure, img[src*='mt2.jpg'],img[src*='pf.gif'],[src*='.gif'], iframe {display:none !important}",
    anime: "div[id*=ad] {display:none !important}",
    yhdmp:
      ".yrtjbmnk_b, .hvitsutz_b {display :none !important; pointer-events: none !important;}", // 樱花动漫
    nbys: "#adltop {display:none !important}", // 泥巴影视视频左上角水印贴片
    button_common:
      "padding: 6px 6px 6px 6px; display: inline-block; color: white;z-index: 114154 !important; border-right: 6px solid #38a3fd !important; border-left: #292f33 !important; border-top: #292f33 !important; border-bottom: #292f33 !important; background: #2563eb; border-radius: 0px 0px 0px 0px; font-weight: 800 !important; text-align: right !important;" // 按钮/输入框通用样式
  },
  function: {}
};

//tagName_appendChild("link", imax.css.globalcss, "head"); // css 外部引用 标签 <link>
//tagName_appendChild("script", imax.js.functionx, "body"); // js 外部引用 标签 <script>

function values() {
  var adsDomain = [
    "pornhub",
    "missav",
    "91porn",
    "avple",
    "18comic",
    "wnacg",
    "ddys",
    "jable",
    "bdys",
    "google",
    "bing",
    "duboku",
    "libvio",
    "tvn",
    "www.5dy",
    "www.555dd",
    "o8tv",
    "instagram",
    "ttsp",
    "tz659",
    "nbys",
    "anime1",
    "yhpdm",
    "yhdmp",
    "zhihu"
  ];

  var url = document.location.href;
  console.log("URL : " + url); // 看看当前 URL
  var i;
  for (i = 0; i < adsDomain.length; i++) {
    if (url.indexOf(adsDomain[i]) !== -1) {
      var values = adsDomain[i]; // 释放参数值
      console.log("Catch it : " + values); // 看看控制台输出了个啥
    }
  }
  return values;
}

function adsDomain_switch(x) {
  // 匹配参数值 执行相应函数
  switch (x) {
    case "pornhub":
      pornhub_interstitialPass();
      css_adsRemove(imax.css.pornhubx, 50, "limbopro");
      tag_adsRemove("script", "ads_batch");
      const custom_style_values_pb =
        "right: 0px !important; padding: 0 !important; position: relative !important;";
      ele_dynamicAppend(
        "h1.floatLeft,div.title-container.translate",
        "如何下载视频",
        custom_style_values_pb + imax.css.button_common,
        'window.open("https://limbopro.com/archives/M3U8-Downloader.html", "_blank")',
        "download_pornhub",
        2,
        "button"
      );
      pornhub_sidebar_ads();
      break;
    case "missav":
      window_open_defuser(); // 打断 window.open 施法
      var ua_missav = navigator.userAgent.toLowerCase();
      var mobile_missav = "mobile";
      cloudflare_captchaBypass();
      css_adsRemove(imax.css.missav);
      tagName_appendChild("script", imax.js.functionx, "body"); // js 外部引用 标签 <script>
      let custom_style_values_miss =
        "font-size: smaller !important; background: #2563eb !important; left: 0px; top: 110px; margin-right: 5px; margin-top: 5px;";
      if (ua_missav.indexOf(mobile_missav) === -1) {
        ele_dynamicAppend(
          "div.mt-4",
          "离开页面视频继续播放",
          custom_style_values_miss + imax.css.button_common,
          "video_loopPlay()",
          "missavX",
          2,
          "button"
        );
        ele_dynamicAppend(
          "div.mt-4",
          "如何下载视频",
          custom_style_values_miss + imax.css.button_common,
          'window.open("https://limbopro.com/archives/M3U8-Downloader.html", "_blank")',
          "how",
          3,
          "button"
        );
        // 添加监听器
        addListenerById(
          "missavX",
          () => {
            video_loopPlay();
          },
          1000
        );
      } else if (ua_missav.indexOf(mobile_missav) > -1) {
        ele_dynamicAppend(
          "div.mt-4",
          "免广告播放",
          custom_style_values_miss + imax.css.button_common,
          "video_Play()",
          "missavX",
          0,
          "button"
        );
        ele_dynamicAppend(
          "div.mt-4",
          "进入全屏",
          custom_style_values_miss + imax.css.button_common,
          "fullscreen()",
          "missavFullScreen",
          2,
          "button"
        );
        ele_dynamicAppend(
          "div.mt-4",
          "暂停",
          custom_style_values_miss + imax.css.button_common,
          "video_pause()",
          "missavPause",
          1,
          "button"
        );
        ele_dynamicAppend(
          "div.mt-4",
          "如何下载视频",
          custom_style_values_miss + imax.css.button_common,
          'window.open("https://limbopro.com/archives/M3U8-Downloader.html", "_blank")',
          "how",
          3,
          "button"
        );
        // 添加监听器
        addListenerById(
          "missavX",
          () => {
            video_Play();
          },
          1000
        );
        addListenerById(
          "missavFullScreen",
          () => {
            fullscreen();
          },
          1000
        );
        addListenerById(
          "missavPause",
          () => {
            video_pause();
          },
          1000
        );
      }
      //missAv_adsRemove();
      break;
    case "91porn":
      cloudflare_captchaBypass();
      css_adsRemove(imax.css.porn91);
      _91porn_videoplay_ads();
      break;
    case "avple":
      cloudflare_captchaBypass();
      css_adsRemove(imax.css.avple);
      tagName_appendChild("script", imax.js.avple, "body");
      break;
    case "18comic":
      css_adsRemove(imax.css.comic_18);
      button_dynamicRemove("#chk_cover", 200);
      _18comic_adsRemove();
      break;
    case "www.5dy":
      css_adsRemove(imax.css.dy555);
      break;
    case "o8tv":
      css_adsRemove(imax.css.dy555);
      break;
    case "www.555dd":
      css_adsRemove(imax.css.dy555);
      break;
    case "wnacg":
      css_adsRemove(imax.css.wnacg);
      break;
    case "ddys":
      css_adsRemove(imax.css.ddrk);
      selector_adsRemove(
        "#sajdhfbjwhe,#kasjbgih,#fkasjgf,img[src*='bcebos']",
        100
      );
      break;
    case "duboku":
      tagName_appendChild("script", imax.js.duboku, "body");
      break;
    case "libvio":
      css_adsRemove(imax.css.libvio);
      break;
    case "nbys":
      css_adsRemove(imax.css.nbys);
      break;
    case "tvn":
      break;
    case "jable":
      cloudflare_captchaBypass();
      css_adsRemove(imax.css.jable);
      jable_adsRemove();
      const url_jable = document.location.href;
      const reg_videos = /^https:\/\/jable\.tv\/videos/gi;
      const custom_style_values_jb_pc =
        "margin-left: 5px; margin-top: 5px; position: static; font-size: smaller !important; background: #2563eb !important; margin-right: 5px;";
      if (url_jable.search(reg_videos) !== -1) {
        ele_dynamicAppend(
          "div h4",
          "复制M3U8文件地址",
          custom_style_values_jb_pc +
            "border-right:#dc3545 !important;" +
            imax.css.button_common,
          "",
          "jablex",
          3,
          "button"
        );
        ele_dynamicAppend(
          "div h4",
          "如何下载视频？",
          custom_style_values_jb_pc + imax.css.button_common,
          'window.open("https://limbopro.com/archives/M3U8-Downloader.html", "_blank")',
          "how",
          1,
          "button"
        );
        ele_dynamicAppend(
          "div h4",
          "",
          custom_style_values_jb_pc +
            "background:white !important; color: black! important;" +
            imax.css.button_common,
          "",
          "copy",
          2,
          "input"
        );
        // 添加监听器
        addListenerById(
          "jablex",
          () => {
            copyText("copy", "jablex", "复制M3U8文件地址");
          },
          0
        );
        video_delayPlay(1000);
        setTimeout(() => {
          repeat_regex.forEach(m3u8_tempt);
        }, 1000);
      }
      break;
    case "bdys":
      css_adsRemove(imax.css.btbdys, 0, "siwtch_button");
      css_adsRemove(imax.css.switch, 0, "switch_class");
      videoAds_accelerateSkip(0.1);
      hrefAttribute_set();
      var url = document.location.href;
      if (url == "https://www.bdys01.com/") {
        if (!document.getElementById("bdys")) {
          ele_dynamicAppend(
            "div.container-xl",
            "隐藏公告",
            "position:inherit; right:92px;" + imax.css.button_common,
            "",
            "bdys",
            1,
            "button"
          );
          addListenerById(
            "bdys",
            () => {
              notice_hidden("div.col-12");
            },
            2000
          );
        }
        if (getCookie("hidden") == 1) {
          notice_hidden("div.col-12");
        }
      }
      break;
    case "instagram":
      // 解除 Instagram 桌面浏览器版禁用右键复制图片
      css_adsRemove(imax.css.instagram);
      break;
    case "ttsp":
      css_adsRemove(imax.css.ttsp);
      break;
    case "tz659":
      css_adsRemove(imax.css.tz659);
      //tag_ads_traversal("body", 0)
      break;
    case "anime1":
      css_adsRemove(imax.css.anime);
      break;
    case "yhdmp":
      css_adsRemove(imax.css.yhdmp);
      break;
    case "yhpdm":
      css_adsRemove(imax.css.yhdmp);
      break;
    case "google":
      js_adsRemove(imax.js.contentFarm);
      css_adsRemove(imax.css.goole);
      var goole_selector = "h3,#bres,[class*='AuVD wHYlTd mnr-c']";
      setAttribute_after(goole_selector, "contentFarm_AdsRemove_Auto()");
      break;
    case "bing":
      js_adsRemove(imax.js.contentFarm);
      break;
    case "zhihu":
      var zhihu_id = "zhihux";
      button_dynamicRemove(
        "[class='Button Modal-closeButton Button--plain']",
        10
      );
      //ele_dynamicAppend("header[role='banner']", "清理中! ♻️", "undefined", "position:fixed; right:0px;", zhihu_id, 3);
      css_adsRemove(imax.css.zhihuAds, 100, "hloyx");
      indexLogin();
      addListener("div.TopNavBar-tab-d8yaD", () => {
        indexLogin();
      });

      /*
          window.onload = href_attributeSet(500, zhihu_id);
          window.onload = addListener("a[class*='css-'],button[class='Button ContentItem-action Button--plain Button--withIcon Button--withLabel']", () => { href_attributeSet(500, zhihu_id) });
          // 循环判定整个页面 scrollHeight 是否变化
          var body_scrollHeightCheck = setInterval(() => {
              var body_scrollHeight_then = document.body.scrollHeight;
              setTimeout(() => {
                  var body_scrollHeight_now = document.body.scrollHeight;
                  if (body_scrollHeight_now > body_scrollHeight_then) {
                      href_attributeSet(500, zhihu_id);
                  }
              }, 500);
          }, 500);
          // 循环判定评论框是否存在且 scrollHeight 是否有变化
          var comment_scrollHeightCheck = setInterval(() => {
              let comment = document.querySelectorAll("div.CommentListV2");
              if (comment.length > 0) {
                  var comment_scrollHeight_then = comment[0].scrollHeight;
                  setTimeout(() => {
                      var comment_scrollHeight_now = comment[0].scrollHeight;
                      if (comment_scrollHeight_now > comment_scrollHeight_then) {
                          href_attributeSet(500, zhihu_id);
                      }
                  }, 500)
              }
          }, 500)
          */

      break;
    default:
      console.log("Catch Nothing!");
  }
}

adsDomain_switch(values()); // 动手吧

// 无数函数及方法的组合使脚本更灵活
// 自动跳过 pornhub interstitial 插页式广告
function pornhub_interstitialPass() {
  const ele_skip = "[onclick*='clearModalCookie']";
  const exist = document.querySelectorAll(ele_skip);
  if (document.querySelectorAll(ele_skip).length > 0) {
    const href = exist[1].href;
    window.location = href;
  }
}

// 设置 cookie // 18comic Javascript
function _18comic_adsRemove() {
  document.cookie = "cover=1";
  document.cookie = "shunt=1";
  document.cookie = "guide=1";
}

// 设置 cookie // missAv Javascript
function missAv_adsRemove() {
  document.cookie =
    "_gat_UA-177787578-7; expires=Thu, 01 Jan 1970 00:00:00 GMT";
}

// 设置 Cookie // 任意
function set_cookie(name, value) {
  document.cookie = name + "=" + value + "; Path=/;";
}

// 通过CSS选择器隐藏广告样式
function selector_adsRemove(selector, time) {
  var i;
  setTimeout(() => {
    var nodelists = document.querySelectorAll(selector);
    for (i = 0; i < nodelists.length; i++) {
      //nodelists[i].remove();
      nodelists[i].style = "display:none ! important;";
    }
  }, time);
}

// 设置 cookie 并移除特定元素
function jable_adsRemove() {
  // Cookie 设定及注入
  document.cookie = "ts_popunder=1";
  document.cookie = "kt_tcookie=1";
  document.cookie = "asgsc262182=2";
  var adsDomain = ["r.trwl1.com", "r.www.com"];

  var i, l;
  for (l = 0; l < adsDomain.length; l++) {
    var css_sel = "a[href*='" + adsDomain[l] + "']";
    var css_catch = [".video-img-box.mb-e-20,.col-6.col-sm-4.col-lg-3"];
    var nodelists = document.querySelectorAll(css_catch);
    for (i = 0; i < nodelists.length; i++) {
      if (nodelists[i].querySelectorAll(css_sel).length > 0) {
        nodelists[i].style.display = "none";
      }
    }
  }
}

// 移除 某个 tag标签
function tag_adsRemove(tagname, keyword) {
  var i;
  var tag = document.getElementsByTagName(tagname);
  for (i = 0; i < tag.length; i++) {
    if (tag[i].src.indexOf(keyword) !== -1) {
      tag[i].remove();
    }
    if (tag[i].innerHTML.indexOf(keyword) !== -1) {
      tag[i].remove();
    }
  }
}

// 在页面动态插入按钮并赋予 onclick 属性
function ele_dynamicAppend(ele, txt, style, func, id, array, tag) {
  let button = document.createElement(tag);
  button.innerHTML = txt;
  button.setAttribute("onclick", func);
  button.setAttribute("id", id);
  button.setAttribute("style", style);
  var here = document.querySelectorAll(ele);
  if (here.length > 0) {
    here[0].insertBefore(button, here[0].childNodes[array]);
    //here[0].appendChild(button);
    console.log("按钮已添加；");
  }
}

// 复制 input 内容
function copyText(id1, id2, Text) {
  // 复制文本按钮
  let corlor = {
    // 定义常量
    css: {
      borderRight_copied: "6px solid white",
      borderRight_recover: "6px solid #38a3fd",
      backgroundColor_copied: "#00AC6A",
      backgroundColor_recover: "#2563eb"
    }
  };

  function border_color(ele, value) {
    // 制作一个循环
    for (let i = 0; i < ele.length; i++) {
      ele[i].style.borderRight = value;
    }
  }

  const ele_1 = document.getElementById(id1);
  const ele_2 = document.getElementById(id2);
  const ele_array = [ele_1, ele_2];

  // 复制工作开始
  const input = document.querySelectorAll("input#copy");
  const range = document.createRange();
  range.selectNode(input[0]);
  const selection = window.getSelection();
  if (selection.rangeCount > 0) selection.removeAllRanges(); // 判断光标是否复制其他内容 如有则清除
  selection.addRange(range);
  document.execCommand("copy");
  // 复制工作结束

  ele_2.innerText = "复制成功！";
  ele_2.style.backgroundColor = corlor.css.backgroundColor_copied;

  border_color(ele_array, corlor.css.borderRight_copied);
  setTimeout(() => {
    ele_2.innerText = Text;
    ele_2.style.backgroundColor = corlor.css.backgroundColor_recover;
    border_color(ele_array, corlor.css.borderRight_recover);
  }, 3000);
}

// Cloudflare recaptcha 绕过
function cloudflare_captchaBypass() {
  var title = document.title;
  if (title.search("Cloudflare") >= 0 || title.search("Attention") >= 0) {
    window.location.reload();
    console.log("captchaBypass done;");
  }
}

/* 循环播放 */
function video_loopPlay() {
  setInterval(function () {
    var ele = ["video[preload='none'],video#player"];
    var ele_catch = document.querySelectorAll(ele);
    if (ele_catch.length > 0) {
      ele_catch[0].play();
      ele_catch[1].play();
      console.log("视频已开启循环播放；");
    }
  }, 1000);
}

/* 播放 */
function window_play() {
  window.player.play();
}

/* 播放 */
function video_Play() {
  //setInterval(function () {
  var ele = ["video[preload='none'],video#player"];
  var ele_catch = document.querySelectorAll(ele);
  if (ele_catch.length > 0) {
    ele_catch[0].play();
    ele_catch[1].play();
    console.log("视频已开始播放；");
  }
  //}, 1000)
}

/* 全屏 */
function fullscreen() {
  const fullScreen = document.querySelector("button[data-plyr='fullscreen']");
  fullScreen.click();
  //fullScreen.requestFullscreen();
  //const fullScreen = document.querySelector('div.plyr__video-wrapper');
  //fullScreen.requestFullscreen();
}

/* 全屏 */
function fullscreen_backup() {
  //setInterval(function () {
  var ele = [".plyr--fullscreen-enabled [data-plyr=fullscreen]"];
  var ele_catch = document.querySelectorAll(ele);
  if (ele_catch.length > 0) {
    ele_catch[0].click();
    //ele_catch[1].click();
    console.log("视频已全屏；");
  }
  //}, 1000)
}

/* 暂停 */
function window_pause() {
  window.player.pause();
}

/* 暂停 */
function video_pause() {
  //setInterval(function () {
  var ele = ["video[preload='none'],video#player"];
  var ele_catch = document.querySelectorAll(ele);
  if (ele_catch.length > 0) {
    ele_catch[0].pause();
    ele_catch[1].pause();
    console.log("视频已暂停；");
  }
  //}, 1000)
}

/* 延后播放 */
function video_delayPlay(time) {
  setTimeout(function () {
    var ele = ["video[preload='none'],video#player"];
    var ele_catch = document.querySelector(ele);
    if (ele_catch) {
      ele_catch.play();
      console.log("视频已延后播放；");
    }
  }, time);
}

/* 添加监听器 bySelector*/
function addListener(selector, funx) {
  setTimeout(() => {
    var ele = document.querySelectorAll(selector);
    for (let index = 0; index < ele.length; index++) {
      ele[index].addEventListener("click", funx, false);
    }
  }, 1000);
}

/* 添加监听器 byID */
function addListenerById(id, funx, time) {
  setTimeout(() => {
    var eleById = document.getElementById(id);
    eleById.addEventListener("click", funx, false);
  }, time);
}

function loopq() {
  alert("Got it!");
}

/* 添加属性 */
function setAttribute_after(x, y) {
  var index;
  var ele = document.querySelectorAll(x);
  for (index = 0; index < ele.length; index++) {
    ele[index].setAttribute("onclick", y);
    console.log("属性设置中...");
  }
}

/* 低端影视是否显示图像 */
function cheat() {
  var ele = document.getElementById("holyx");
  ele.innerHTML = imax.css.ddrk_cheat;
  setTimeout(() => {
    ele.innerHTML = imax.css.ddrk_hidden;
    console.log("正在切换剧集；");
  }, 150);
}

// 禁止新页面跳转
function hrefAttribute_set() {
  var href = document.querySelectorAll("a");
  var i;
  if (href.length > 0) {
    console.log("新标签页打开链接已被禁止；");
    for (i = 0; i < href.length; i++) {
      href[i].target = "_self";
    }
  }
}

// 禁止新页面跳转另一种实现 循环
function href_attributeSet(time, id) {
  document.getElementById(id).style.background = "black";
  document.getElementById(id).innerHTML = "清理中! ♻️";
  setTimeout(() => {
    // 监控页面是否有新的 button
    let selector = "button[class*='Button PaginationButton']";
    let ele_button = document.querySelectorAll(selector);
    if (ele_button.length > 0) {
      window.onload = addListener(selector, () => {
        href_attributeSet(time, id);
      });
    }
    let times = 0;
    let loop = setInterval(() => {
      // 修改属性
      times += 1;
      let href = document.querySelectorAll("a");
      let i;
      for (i = 0; i < href.length; i++) {
        if (href[i].target == "_blank") {
          href[i].setAttribute("target", "_self");
        }
      }
      let href_Length = document.querySelectorAll("a[target='_blank']").length;
      if (href_Length === 0 && times >= 2) {
        clearInterval(loop);
        if (document.getElementById(id)) {
          document.getElementById(id).innerHTML = "100%! ♻️";
          document.getElementById(id).style.background = "green";
          console.log("循环第" + times + "遍；");
          console.log("清理完毕!");
        }
      }
    }, time);
  }, time);
}

// 动态创建引用外部js JavaScript
function js_adsRemove(url) {
  var script = document.createElement("script");
  script.src = url;
  document.body.appendChild(script);
  console.log("JavaScript脚本新增完毕！");
}

// 动态创建并引用外部资源 外部样式表 外部脚本
function tagName_appendChild(tagname, url, where) {
  var eleCreate = document.createElement(tagname);
  if (tagname == "script") {
    eleCreate.src = url;
  } else if (tagname == "link") {
    eleCreate.href = url;
  }
  if (where == "body") {
    document.body.appendChild(eleCreate);
  } else if (where == "head") {
    document.head.appendChild(eleCreate);
  }
}

// 动态创建引用内部资源 内嵌式样式 内嵌式脚本
function css_adsRemove(newstyle, delaytime, id) {
  setTimeout(() => {
    var creatcss = document.createElement("style");
    creatcss.id = id;
    creatcss.innerHTML = newstyle;
    document.getElementsByTagName("head")[0].appendChild(creatcss);
    console.log("CSS样式新增完毕！");
  }, delaytime);
}

// 循环模拟模拟点击
function button_dynamicRemove(selector, times) {
  var initCount = 0;
  var loop = setInterval(() => {
    var ele = document.querySelectorAll(selector);
    if (ele.length > 0) {
      ele[0].click();
    }
    initCount += 1;
    if (initCount == times) {
      clearInterval(loop);
    }
  }, 0);
}

// 知乎循环跳转绕过登录页
function indexLogin() {
  // 跳转至热门话题 Explore 或 随机
  let url = document.location.href;
  let cssSelector =
    "a[href='//www.zhihu.com/'],a[href='//www.zhihu.com'],a[href='https://www.zhihu.com']";
  let rewrite_url =
    "https://www.zhihu.com/knowledge-plan/hot-question/hot/0/hour";
  let reg = /^https:\/\/www.zhihu.com\/signin/gi;
  if (url.search(reg) !== -1) {
    window.location = rewrite_url;
  }

  setTimeout(() => {
    // 延时执行函数优化
    var ele = document.querySelectorAll(cssSelector);
    if (ele.length > 0) {
      let i;
      for (i = 0; i < ele.length; i++) {
        ele[i].href = rewrite_url;
      }
    }
  }, 300);

  /*
  var url = document.location.href;
  var url_list = [
      "https://www.zhihu.com/knowledge-plan/hot-question/hot/",
  ]
  var rand = Math.floor(Math.random() * url_list.length);
  var url_random = url_list[rand];
  var reg = /^https:\/\/www.zhihu.com\/signin/gi;
  if (url.search(reg) !== -1) {
      window.location = url_random;
  }
  */
}

/* 视频页广告加速跳过 */
function videoAds_accelerateSkip(fasterx) {
  // https://github.com/gorhill/uBlock/wiki
  /// nano-setInterval-booster.js
  /// alias nano-sib.js
  //console.log("视频广告加速")
  let needleArg = "{{1}}";
  if (needleArg === "{{1}}") {
    needleArg = "";
  }
  let delayArg = "{{2}}";
  if (delayArg === "{{2}}") {
    delayArg = "";
  }
  let boostArg = "{{3}}";
  if (boostArg === "{{3}}") {
    boostArg = "";
  }
  if (needleArg === "") {
    needleArg = ".?";
  } else if (needleArg.charAt(0) === "/" && needleArg.slice(-1) === "/") {
    needleArg = needleArg.slice(1, -1);
  } else {
    needleArg = needleArg.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  const reNeedle = new RegExp(needleArg);
  let delay = delayArg !== "*" ? parseInt(delayArg, 10) : -1;
  if (isNaN(delay) || isFinite(delay) === false) {
    delay = 1000;
  }
  let boost = parseFloat(boostArg);
  boost =
    isNaN(boost) === false && isFinite(boost)
      ? Math.min(Math.max(boost, fasterx), 50)
      : fasterx;
  self.setInterval = new Proxy(self.setInterval, {
    apply: function (target, thisArg, args) {
      const [a, b] = args;
      if ((delay === -1 || b === delay) && reNeedle.test(a.toString())) {
        args[1] = b * boost;
      }
      return target.apply(thisArg, args);
    }
  });
}

// overridePropertyRead 覆盖属性读取
/// https://github.com/AdguardTeam/Scriptlets/blob/master/wiki/about-scriptlets.md#set-constant

var repeat_regex = [
  "https:?//.*?hls.*?.m3u8",
  "https:?//.*?phncdn.*?hls.*?.m3u8",
  "https:?//.*?mushroomtrack.*?.m3u8"
];

function m3u8_tempt(x) {
  var i, url_result;
  var url_regex = new RegExp(x, "gi");
  var ele = ["script", "a"];
  var ele_catch = document.querySelectorAll(ele);
  for (i = 0; i < ele_catch.length; i++) {
    if ((url_result = url_regex.exec(ele_catch[i].innerHTML)) != null) {
      document.getElementById("copy").value = url_result;
      console.log("Catch it");
    }
  }
}

function pornhub_sidebar_ads() {
  setTimeout(() => {
    var ele_parent = ["div"];
    var ele_children = ["img[data-title][title][srcset]"];
    var ele_attributes = ["class"];
    var i;

    const css_Selctors = document.querySelectorAll(ele_parent);

    for (i = 0; i < css_Selctors.length; i++) {
      if (css_Selctors[i].querySelectorAll(ele_children).length !== 0) {
        if (css_Selctors[i].getAttribute(ele_attributes)) {
          if (css_Selctors[i].attributes.length == 1) {
            if (css_Selctors[i].children.length == 2) {
              console.log(css_Selctors[i]);
              css_Selctors[i].style.display = "none";
            }
          }
        }
      }
    }
  }, 500);
}

function _91porn_videoplay_ads() {
  //setTimeout(() => {
  var ele_parent = ["div"];
  var ele_children = ['a[target="_blank"]  > img[src*=".gif"]'];
  var i;

  const css_Selctors = document.querySelectorAll(ele_parent);

  for (i = 0; i < css_Selctors.length; i++) {
    if (css_Selctors[i].querySelectorAll(ele_children).length !== 0) {
      if (css_Selctors[i].attributes.length == 0) {
        if (css_Selctors[i].children.length == 9) {
          console.log(css_Selctors[i]);
          css_Selctors[i].style.display = "none";
        }
      }
    }
  }
  //}, 500);
}

function tag_ads_traversal(selector, i) {
  const css_Selctors = document.querySelectorAll(selector);
  css_Selctors[i].style.display = "none";
}

// Get Cookies 获取指定命名的cookie 的值
function getCookie(cname) {
  var name = cname + "=";
  var ca = document.cookie.split(";");
  for (var i = 0; i < ca.length; i++) {
    var c = ca[i].trim();
    if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
  }
  return "";
}

// 哔滴影视隐藏公告广告
function notice_hidden(selector) {
  // bdys
  document.querySelector(selector).classList.add("switch"); // 隐藏公告
  document.cookie = "hidden=1";
  document.getElementById("bdys").innerHTML = "查看公告";
  addListenerById(
    "bdys",
    () => {
      notice_show("div.col-12");
    },
    2000
  );
}

// 哔滴影视展示公告
function notice_show(selector) {
  document.querySelector(selector).classList.remove("switch"); // 展示公告
  document.cookie = "hidden=0";
  document.getElementById("bdys").innerHTML = "隐藏公告";
  addListenerById(
    "bdys",
    () => {
      notice_hidden("div.col-12");
    },
    2000
  );
}

// window.open-defuser.js
// https://github.com/gorhill/uBlock/wiki/Resources-Library#windowopen-defuserjs-

function window_open_defuser() {
  "use strict";
  let arg1 = "{{1}}";
  if (arg1 === "{{1}}") {
    arg1 = "";
  }
  let arg2 = "{{2}}";
  if (arg2 === "{{2}}") {
    arg2 = "";
  }
  let arg3 = "{{3}}";
  if (arg3 === "{{3}}") {
    arg3 = "";
  }
  const log = /\blog\b/.test(arg3) ? console.log.bind(console) : () => {};
  const newSyntax = /^[01]?$/.test(arg1) === false;
  let pattern = "";
  let targetResult = true;
  let autoRemoveAfter = -1;
  if (newSyntax) {
    pattern = arg1;
    if (pattern.startsWith("!")) {
      targetResult = false;
      pattern = pattern.slice(1);
    }
    autoRemoveAfter = parseInt(arg2);
    if (isNaN(autoRemoveAfter)) {
      autoRemoveAfter = -1;
    }
  } else {
    pattern = arg2;
    if (arg1 === "0") {
      targetResult = false;
    }
  }
  if (pattern === "") {
    pattern = ".?";
  } else if (/^\/.+\/$/.test(pattern)) {
    pattern = pattern.slice(1, -1);
  } else {
    pattern = pattern.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  const rePattern = new RegExp(pattern);
  const createDecoy = function (tag, urlProp, url) {
    const decoy = document.createElement(tag);
    decoy[urlProp] = url;
    decoy.style.setProperty("height", "1px", "important");
    decoy.style.setProperty("position", "fixed", "important");
    decoy.style.setProperty("top", "-1px", "important");
    decoy.style.setProperty("width", "1px", "important");
    document.body.appendChild(decoy);
    setTimeout(() => decoy.remove(), autoRemoveAfter * 1000);
    return decoy;
  };
  window.open = new Proxy(window.open, {
    apply: function (target, thisArg, args) {
      log("window.open:", ...args);
      const url = args[0];
      if (rePattern.test(url) !== targetResult) {
        return target.apply(thisArg, args);
      }
      if (autoRemoveAfter < 0) {
        return null;
      }
      const decoy = /\bobj\b/.test(arg3)
        ? createDecoy("object", "data", url)
        : createDecoy("iframe", "src", url);
      let popup = decoy.contentWindow;
      if (typeof popup === "object" && popup !== null) {
        Object.defineProperty(popup, "closed", { value: false });
      } else {
        const noopFunc = function () {}.bind(self);
        popup = new Proxy(self, {
          get: function (target, prop) {
            if (prop === "closed") {
              return false;
            }
            const r = Reflect.get(...arguments);
            if (typeof r === "function") {
              return noopFunc;
            }
            return target[prop];
          },
          set: function () {
            return Reflect.set(...arguments);
          }
        });
      }
      if (/\blog\b/.test(arg3)) {
        popup = new Proxy(popup, {
          get: function (target, prop) {
            log("window.open / get", prop, "===", target[prop]);
            return Reflect.get(...arguments);
          },
          set: function (target, prop, value) {
            log("window.open / set", prop, "=", value);
            return Reflect.set(...arguments);
          }
        });
      }
      return popup;
    }
  });
}
