var _blank = document.querySelectorAll("a");
var i;
for (i = 0; i < _blank.length; i++) {
  _blank[i].target = "_self";
}
