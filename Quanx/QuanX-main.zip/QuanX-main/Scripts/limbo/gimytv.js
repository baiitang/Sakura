var gimy = document.querySelectorAll("div.stui-pannel.clearfix");
gimy[1].style.display = "none";
gimy[3].style.display = "none";
