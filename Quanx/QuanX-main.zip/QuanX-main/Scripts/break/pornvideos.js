/******************************
https://github.com/yqc007/QuantumultX/blob/master/PornVideosCrack.js
脚本功能：欲漫涩解锁会员视频
软件版本：2.3.0+83
下载地址：https://xohnly.com/?dc=yrga5
脚本作者：Hausd0rff
更新时间：2022-09-27
脚本发布：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️此脚本仅供学习与交流，请勿转载与贩卖！⚠️⚠️⚠️

[rewrite_local]
# > 欲漫涩解锁会员漫画&视频
^https?:\/\/.*\.com\/api\/app\/user\/info$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/PornComicsCrack.js
^https?:\/\/.*\.com\/api\/app\/media url script-request-header https://raw.githubusercontent.com/yqc007/QuantumultX/master/PornVideosCrack.js

[mitm]
hostname = zjgeo.eqobc.com, xnour.xonap.com, opzzy.kefsww.com, tqrbq.mpckv.com
*******************************/

var hausd0rff = $request["\x75\x72\x6c"]["\x72\x65\x70\x6c\x61\x63\x65"](/_\d+\./g, "\x2e");

$done({ url: hausd0rff });
