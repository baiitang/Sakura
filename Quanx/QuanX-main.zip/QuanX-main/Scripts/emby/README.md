# 引用地址
```
https://github.com/rartv/EmbyPublic/blob/test/quantumult-x/emby-plugin.conf
https://github.com/rartv/EmbyPublic/blob/test/quantumult-x/download-file-rename.js
https://github.com/rartv/EmbyPublic/blob/test/surge/emby-plugin.js
```
