⚠️ 禁止fork！

# 访问量
![](http://profile-counter.glitch.me/RuCu6-QuanX/count.svg)

# 鸣谢
按字母排序
- [@app2smile](https://github.com/app2smile/rules)
- [@blackmatrix7](https://github.com/blackmatrix7/ios_rule_script/tree/master)
- [@kokoryh](https://github.com/kokoryh/Script)
- [@Keywos](https://github.com/Keywos/rule)
- [@Maasea](https://github.com/Maasea/sgmodule)
- [@zmqcherish](https://github.com/zmqcherish/proxy-script)
