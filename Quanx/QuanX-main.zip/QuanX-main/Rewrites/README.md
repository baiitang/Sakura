# 引用地址 - AppUnlock.conf
```
https://github.com/qiangxinglin/Emby/blob/main/QuantumultX/emby.conf
https://github.com/I-am-R-E/Functional-Store-Hub/blob/Master/KuWoMusic/KuWoMusic.QuantumultX.snippet
https://github.com/yqc007/QuantumultX/blob/master/NotabilityProCrack.js
https://github.com/I-am-R-E/Functional-Store-Hub/blob/Master/WPSOffice/QuantumultX.snippet
https://github.com/yqc007/QuantumultX/blob/master/WPSDocerVIPowerCrack.js
https://github.com/yqc007/QuantumultX/blob/master/WPSDocerVIPuserCrack.js
```
# 引用地址 - MyBlockAds.conf
```
https://github.com/zZPiglet/Task/blob/master/noredirect.conf
https://github.com/ddgksf2013/Cuttlefish/blob/master/Rewrite/MyAdRule.conf
https://github.com/ddgksf2013/Cuttlefish/blob/master/Rewrite/AdBlock/Bilibili.conf
https://github.com/chouchoui/QuanX/blob/master/Scripts/xiaohongshu/xiaohongshu.ad.sgmodule
https://github.com/chouchoui/QuanX/blob/master/Scripts/xiaohongshu/xiaohongshu.ad.js
https://github.com/zZPiglet/Task/blob/master/UnblockURLinWeChat.conf
https://github.com/zmqcherish/proxy-script/blob/main/weibo.conf
https://github.com/zmqcherish/proxy-script/blob/main/weibo_main.js
https://github.com/yjqiang/surge_scripts/blob/main/scripts/weibo/weibo_sdkad.js
https://github.com/Maasea/sgmodule/blob/master/YoutubeAds.sgmodule
https://github.com/Maasea/sgmodule/blob/master/Script/Youtube/youtube.js
https://github.com/yjqiang/surge_scripts/blob/main/modules/zhihu/zhihu_website.sgmodule
https://github.com/blackmatrix7/ios_rule_script/blob/master/script/zhihu/zhihu_plus.qxrewrite
```
# 引用地址 - TestFlight.conf
```
https://github.com/id77/QuantumultX/blob/master/rewrite/other.conf
https://github.com/NobyDa/Script/blob/master/QuantumultX/TestFlightDownload.conf
```
# 引用地址 - WebPage.conf
```
https://github.com/DivineEngine/Profiles/blob/master/Quantumult/Rewrite/General.conf
https://github.com/limbopro/Adblock4limbo/blob/main/Adblock4limbo.conf
```
